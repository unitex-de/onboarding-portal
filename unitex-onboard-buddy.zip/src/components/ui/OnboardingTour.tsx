import { useState } from "react";
import { X, ArrowRight, LayoutDashboard, Building2, FolderUp, PenLine, CheckSquare, HelpCircle } from "lucide-react";
import { useOnboarding } from "@/lib/onboarding-state";

const STEPS = [
  {
    icon: LayoutDashboard,
    title: "Ihr Dashboard",
    body: "Hier sehen Sie Ihren Gesamtfortschritt auf einen Blick. Der Fortschrittsring zeigt, wie weit Sie beim Onboarding sind.",
  },
  {
    icon: Building2,
    title: "1 · Stammdaten",
    body: "Tragen Sie alle Unternehmensdaten ein: Grunddaten, Kontakt, Bankverbindung, GLN & Filialen sowie GWG-Pflichtangaben.",
  },
  {
    icon: FolderUp,
    title: "2 · Dokumente hochladen",
    body: "Laden Sie alle für Ihre Rechtsform erforderlichen Dokumente hoch. Die Liste passt sich automatisch an Ihre Rechtsform an.",
  },
  {
    icon: PenLine,
    title: "3 · Signaturen",
    body: "Nach mindestens 75% Gesamtfortschritt können Sie Verträge digital über PandaDoc unterzeichnen.",
  },
  {
    icon: CheckSquare,
    title: "Zur Prüfung freigeben",
    body: "Sobald alles bei 100% ist, erscheint der Button 'Zur Prüfung freigeben'. Danach meldet sich Ihr unitex-Ansprechpartner.",
  },
];

interface OnboardingTourProps {
  /** If provided, the component only renders the trigger button at the bottom of the screen */
  triggerOnly?: boolean;
}

export function OnboardingTour({ triggerOnly }: OnboardingTourProps) {
  const { state, update } = useOnboarding();
  // Tour is never shown automatically – only when isOpen=true
  const [isOpen, setIsOpen] = useState(false);
  const [step, setStep] = useState(0);

  // Don't render for Admins
  if (state.role === "admin") return null;

  const current = STEPS[step];
  const Icon = current.icon;
  const isLast = step === STEPS.length - 1;

  const openTour = () => {
    setStep(0); // Always restart from the beginning
    setIsOpen(true);
  };

  const dismiss = () => {
    setIsOpen(false);
    update({ tourSeen: true });
  };

  const next = () => {
    if (isLast) dismiss();
    else setStep((s) => s + 1);
  };

  return (
    <>
      {/* Floating "Tour starten" trigger button at bottom of screen */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40">
        <button
          onClick={openTour}
          className="inline-flex items-center gap-2 rounded-full bg-card border border-border shadow-lg px-4 py-2.5 text-sm font-medium text-secondary hover:text-foreground hover:border-primary/60 transition-all hover:shadow-xl"
        >
          <HelpCircle className="h-4 w-4 text-primary" />
          Tour starten
        </button>
      </div>

      {/* Tour modal overlay */}
      {isOpen && (
        <div className="fixed inset-0 z-50 bg-background/70 backdrop-blur-sm flex items-center justify-center p-6">
          <div className="w-full max-w-sm rounded-2xl border border-border bg-card shadow-2xl overflow-hidden">
            {/* Progress dots */}
            <div className="flex items-center justify-between px-6 pt-5">
              <div className="flex gap-1.5">
                {STEPS.map((_, i) => (
                  <div key={i}
                    className={[
                      "h-1.5 rounded-full transition-all duration-300",
                      i === step ? "w-6 bg-primary" : i < step ? "w-3 bg-primary/40" : "w-3 bg-border",
                    ].join(" ")}
                  />
                ))}
              </div>
              <button
                onClick={dismiss}
                className="text-muted hover:text-foreground transition-colors"
                aria-label="Tour überspringen"
                title="Tour überspringen"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="px-6 py-5 space-y-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/15 border border-primary/20">
                <Icon className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-display text-lg font-semibold">{current.title}</h3>
                <p className="mt-2 text-sm text-secondary leading-relaxed">{current.body}</p>
              </div>
            </div>

            <div className="border-t border-border px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-xs text-muted">{step + 1} / {STEPS.length}</span>
                <button
                  onClick={dismiss}
                  className="text-xs text-muted hover:text-secondary underline underline-offset-2 transition-colors"
                >
                  Überspringen
                </button>
              </div>
              <button onClick={next}
                className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors"
              >
                {isLast ? "Los geht's!" : "Weiter"}
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
